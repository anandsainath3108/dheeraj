package com.capg.ui;


import java.util.Scanner;

import com.capg.bean.Customer;
import com.capg.service.BankServiceImp;

public class BankClient {

	public static void main(String[] args) {
		BankServiceImp service = new BankServiceImp();
		while (true) {
			
			System.out.println("Select an option ");
			System.out.println("1.Create Account ");
			System.out.println("2.Show Balance ");
			System.out.println("3.Deposit ");
			System.out.println("4.Withdraw ");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Print Transactions ");

			Scanner sc = new Scanner(System.in);
			int sel = sc.nextInt();

			switch (sel) {
			case 1: 
				Customer bean = new Customer();
				System.out.println("Enter ur Name");
				String name = sc.next();
				System.out.println("Enter customer address");
				String address = sc.next();
				System.out.println("Enter customer phone number");
				String phonenumber = sc.next();
				System.out.println("Enter email");
				String email = sc.next();
				System.out.println("Enter date of birth");
				String dateofbirth = sc.next();
				/*bean.getCustomerid();
				bean.getAccountnumber();
				bean.getPin();*/
				bean.setName(name);
				bean.setAddress(address);
				//bean.getBalance();
				bean.setPhonenumber(phonenumber);
				bean.setEmail(email);
				bean.setDateofbirth(dateofbirth);
				boolean correct = service.validation(bean);
				if (correct) {
					boolean isAdded = service.CreateAccount(bean);
					if (isAdded) {
						System.out.println("Record added sucessfully");
					System.out.println(bean);

					} else {
						System.err.println("Record not added..");
					}
				} else {
					System.err.println("this is error");

				}
			

				break;
			case 2: 
//Customer bean1=new Customer();
System.out.println("enter your customer id");
int customerid=sc.nextInt();
System.out.println("enter ur pin");
int pin=sc.nextInt();
//bean1.setCustomerid(customerid);
//bean1.setPin(pin);
Customer correct1=service.displayCustomer(customerid);
System.out.println(correct1);
	System.out.println(correct1.getBalance());	
			
			break;
			
			case 3:
				
				System.out.println("enter your customer id");
				int customerid1=sc.nextInt();
				System.out.println("enter ur pin");
			int pin1=sc.nextInt();
			
			Customer correct2=service.displayCustomer(customerid1); 
			System.out.println(correct2);
				System.out.println("enter amount to deposit");
				int amount=sc.nextInt();
				int amount1=correct2.getBalance()+amount;
				correct2.setBalance(amount1);
				System.out.println(correct2);
				/*boolean amountcorrect=service.validAmount(amount);
				
				if(amountcorrect){
					
				int bal=service.Deposit(amount,bean2);
				
				System.out.println("Deposited amount is "+amount+"newBalance: "+bal);
				}
				
				
			}else{System.out.println("Invalid Amount. Please enter a POSITIVE amount. Thanks. :");}*/
			
			break;
			
			
			case 4:
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			}

		}
	}
}
