package com.capg.dao;

import java.util.HashMap;
import java.util.Map;

import com.capg.bean.Customer;

public class BankDaoImp implements IBankDao {

	private static Map<Integer, Customer> account = new HashMap<Integer, Customer>();
	

	public boolean CreateAccount(Customer c) {
		// TODO Auto-generated method stub
		int key = c.getCustomerid();
		account.put(key, c);
		
		return account.containsValue(c);
	}

	public boolean ShowBalance(int customerid, int pin) {
		boolean flag = false;
for(Customer c:account.values())
			if (c.getCustomerid() == customerid && c.getPin() == pin) {
				flag = true;
			}
		return flag;}


	@Override
	public int Deposit(int curbalance,Customer c) {
	
c.setBalance(curbalance);
	 return c.getBalance();
		
	}

	@Override
	public void Withdraw() {
		// TODO Auto-generated method stub

	}

	@Override
	public void FundTransfer() {
		// TODO Auto-generated method stub

	}

	@Override
	public void PrintTransactions() {
		// TODO Auto-generated method stub

	}

	@Override
	public Customer displayCustomer(int cid) {
		// TODO Auto-generated method stub
		Customer cust=null;
		for (Customer c : account.values()) {
			if(c.getCustomerid()==cid){
				cust=c;
			}
		}
		return cust;
	}

	
}
