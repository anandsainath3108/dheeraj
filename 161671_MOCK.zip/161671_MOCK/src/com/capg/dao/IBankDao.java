package com.capg.dao;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.capg.bean.Customer;

public interface IBankDao {
	
	public boolean CreateAccount(Customer c);

	
	public void Withdraw();
	public void FundTransfer();
	public void PrintTransactions();
	public boolean ShowBalance(int customerid,int pin);
public Customer displayCustomer(int cid);
	public int Deposit(int amount, Customer c);



	


	
}
