package com.capg.service;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.capg.bean.Customer;
import com.capg.dao.BankDaoImp;
import com.capg.exception.InvalidInputException;

public class BankServiceImp implements IBankService {
	BankDaoImp dao = new BankDaoImp();

	@Override
	public boolean CreateAccount(Customer c) {
	
		return dao.CreateAccount(c);
	}
	
	public boolean validation(Customer bean){
		boolean flag=false;
		if(isValidName(bean.getName()) &&  isValidaddress(bean.getAddress()) && isValidemail(bean.getEmail()) &&  isValidphonenumber(bean.getPhonenumber()) &&  isValiddob(bean.getDateofbirth()) && isValidcustomerid(bean.getCustomerid()))
		{ flag=true;}
		return flag;
	}

	public boolean isValidName(String name) {
		if (((name != null) && name.matches("[A-Z][a-z]+"))) {
			return true;
		} else {
			throw new InvalidInputException(
					" : Name cannot be NULL (or) INVALID Name.");}}
		
		
		public boolean isValidaddress(String address ) {
			if (((address != null) && address.matches("[0-9]"))) {
				return true;
			} else {
				throw new InvalidInputException(
						" : address cannot be NULL (or) INVALID address.");
			}
		}

		public boolean isValidemail(String email) {
			if (((email != null) && email.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"   + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"))) {
				return true;
			} else {
				throw new InvalidInputException(
						" : email cannot be NULL (or) INVALID email.");}
			}
	
	
	
			public boolean isValidphonenumber(String phonenumber) {
				if (((phonenumber != null) && phonenumber.matches("[4-9][0-9]{9}"))) {
					return true;
				} else {
					throw new InvalidInputException(
							" : Name cannot be NULL (or) INVALID Name.");}
				}
	
				public boolean isValiddob(String dob) {
					if (((dob != null) && dob.matches("^([0-2][0-9]||3[0-1])/(0[0-9]||1[0-2])/([0-9][0-9])?[0-9][0-9]$"))) {
						return true;
					} else {
						throw new InvalidInputException(
								" : dob cannot be NULL (or) INVALID dob.");}
					}
	
	
					public boolean isValidcustomerid(int customerid) {
						if (customerid>=100) {
							return true;
						} else {
							throw new InvalidInputException(
									" : customerid cannot be Null (or) INVALID Customer.");}
						}
	
	
	
	
					 public boolean validAmount(int amount) {
					        if (amount > 0) {
					            return true;
					        } else {
					            throw new InvalidInputException(" : Invalid Amount. Please enter a POSITIVE amount. Thanks. :) \n");
					        }
					    }

	
	
	
	
	@Override
	public boolean ShowBalance(int customerid,int pin) {
		return dao.ShowBalance(customerid,pin);
		// TODO Auto-generated method stub

	}

	@Override
	public int Deposit(int amount,Customer c) 
	{
		// TODO Auto-generated method stub
int amount1=0;
		amount1= c.getBalance()+amount;
	
		return dao.Deposit(amount1,c);

	
	
}
	@Override
	public void Withdraw(int customerid, String name, int amount) {
		// TODO Auto-generated method stub

	}

	@Override
	public void FundTransfer(int customerid, int transferid, int amount) {
		// TODO Auto-generated method stub

	}

	@Override
	public void PrintTransactions() {
		// TODO Auto-generated method stub

	}

	@Override
	public Customer displayCustomer(int cid) {
		// TODO Auto-generated method stub
		return dao.displayCustomer(cid);
	}


		
	}
	


