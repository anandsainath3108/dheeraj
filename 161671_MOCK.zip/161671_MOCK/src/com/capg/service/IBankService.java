package com.capg.service;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.capg.bean.Customer;

public interface IBankService {
	
	public boolean CreateAccount(Customer c);
	public boolean ShowBalance(int customerid,int pin);
	public int Deposit(int amount,Customer c);
	public void Withdraw(int customerid,String name,int amount);
	public void FundTransfer(int customerid,int transferid,int amount);
	public void PrintTransactions();
	public Customer displayCustomer(int cid);

	
	
	
	
	
}
